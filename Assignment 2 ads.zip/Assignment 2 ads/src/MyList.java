public interface MyList<E> {
}
